# HandWriteAR Air-Writing Prototype

A browser-based proof of concept for **HandWriteAR**, using MediaPipe hand tracking to capture index-finger air-writing and compare the movement against predefined target patterns.

## What it does

The prototype:

- Uses the webcam to track one hand.
- Uses the index fingertip as an invisible pen.
- Displays a target trajectory.
- Records the user's air-writing movement.
- Compares the trajectory using Dynamic Time Warping (DTW).
- estimates stroke-direction accuracy.
- estimates movement smoothness.
- provides an overall feedback score.

Available patterns:

- Line
- L
- V
- O
- C
- Z
- S

## Run it on GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose:
   - Source: **Deploy from a branch**
   - Branch: **main**
   - Folder: **/ (root)**
5. Save.
6. Open the generated GitHub Pages URL.
7. Allow camera access.
8. Select a pattern.
9. Click **Start Writing**.
10. Air-write with your index finger.
11. Click **Finish**.

Camera access requires a secure context such as GitHub Pages (`https://`).

## Research prototype status

This is a **proof of concept**, not a diagnostic system. It currently evaluates trajectory similarity, direction and smoothness. It does not diagnose dysgraphia and does not measure pencil pressure, grip, paper contact, or the final written character.

## Suggested next stage

For the full HandWriteAR research system, extend the prototype with:

1. Letter-specific stroke templates.
2. Stroke-order detection.
3. Starting-point and ending-point analysis.
4. Velocity, acceleration and jerk.
5. Hesitation and pause detection.
6. Reversal detection.
7. Individual learner profiles.
8. Teacher dashboard.
9. Adaptive feedback.
10. A paper-and-pencil version that combines hand tracking with handwriting-image analysis.

## Technology

- HTML/CSS/JavaScript
- MediaPipe Hands
- Webcam
- Dynamic Time Warping
- Browser-based computer vision

The system is designed as an early experimental component of the broader HandWriteAR concept: real-time formative assessment and feedback for orthographic motor skills.
